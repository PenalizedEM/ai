#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2017/12/4 上午11:09'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'wide_build_model_data.py.py'
"""
import datetime
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
from pyspark.mllib.linalg import SparseVector
from pyspark.mllib.linalg import DenseVector
from pyspark.mllib.linalg import Vectors
from pyspark.mllib.regression import LabeledPoint
from pyspark.mllib.util import MLUtils
import util

import sys
reload(sys)
sys.setdefaultencoding("utf-8")

FEEDBACK_DIR = "hdfs://Ucluster/olap/da/wide_dl/feed_back/"
TRAIN_DIR = "hdfs://Ucluster/olap/da/wide_dl/train/"
TEST_DIR = "hdfs://Ucluster/olap/da/wide_dl/test/"
MODEL_WINDOW = 1

ABNORMAL_USER = ['0123456789abcde', '012345678912345','123456789012345','0','000000', \
                 '00000000','00000000000000','000000000000000','0000000000000000','000000011234564',
                '111111111111111', '', 'UNKNOWN', 'Unknown', '+++++000000000', '+GSN:808DCF89','000000000000026']

def main():
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    if len(sys.argv)==1:
        start_day = datetime.datetime.today() - datetime.timedelta(1)
    elif len(sys.argv)==2:
        start_day = datetime.datetime.strptime(sys.argv[1], "%Y-%m-%d")
    elif len(sys.argv)>2:
        start_day = datetime.datetime.strptime(sys.argv[1], "%Y-%m-%d")
        MODEL_WINDOW = int(float(sys.argv[2]))
    end_day = start_day - datetime.timedelta(MODEL_WINDOW)
    spark = SparkSession.builder.master('yarn-client')\
        .appName('build_mode_data:' + inDate)\
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse')\
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    global features
    features = util.get_all_features()
    # 获取反馈数据
    feedback_data = load_feedback(spark, start_day, end_day)
    # 均衡抽样
    balance_feedback = build_balance_feedback(sc, feedback_data)
    train, test = balance_feedback.randomSplit([0.8, 0.2])
    csv_out(sc, train, TRAIN_DIR + inDate)
    csv_out(sc, test, TEST_DIR + inDate)
    #MLUtils.saveAsLibSVMFile(train, TRAIN_DIR + inDate)
    #MLUtils.saveAsLibSVMFile(test, TEST_DIR + inDate)
    spark.stop()


def load_feedback(spark, start_day, end_day):
    feedback = []
    sc = spark.sparkContext
    while start_day > end_day:
        mode_day = start_day.strftime("%Y-%m-%d")
        feedback_day = load_feedback_day(spark, mode_day)
        feedback.append(feedback_day)
        start_day = start_day - datetime.timedelta(1)
    return sc.union(feedback)


def load_feedback_day(spark, inDate):
    return spark.read.load(FEEDBACK_DIR + inDate).rdd.\
        map(lambda x: [x['label'], [x[feature] for feature in features]])\
        .filter(lambda x: x[1][0] not in set(ABNORMAL_USER))


def build_balance_feedback(sc, feedback):
    feed_back_num = feedback.map(lambda x: [x[0], 1]).reduceByKey(lambda a,b :a + b).collectAsMap()
    ratio = 3
    fraction = dict()
    positive_num = feed_back_num.get(1)
    sample_num = ratio * positive_num
    for label, num in feed_back_num.iteritems():
        fraction[label] = 1
        if label==0 and sample_num < num:
            fraction[label] = sample_num *1.0/num
    return feedback.sampleByKey(False, fraction)\
        .map(lambda (label, features): [label, features[1:]])

def csv_out(sc, rdd, dir):
    """csv 格式保存输出
    """
    rdd.repartition(1000).map(lambda x: str(x[0])+"," + ",".join(map(str, x[1])))\
        .saveAsTextFile(dir)


if __name__ == "__main__":
    main()


