#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""计算用户的偏好
@Time    : '2018/3/7 下午3:21'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'user_pref_day.py'
"""
import datetime
import sys
reload(sys)
sys.setdefaultencoding("utf-8")
import numpy as np
import json
import datetime
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
import pyspark.sql.functions as sf
import math
from collections import defaultdict
from pyspark.sql import Row


def main():
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    if len(sys.argv)==1:
        start_day = datetime.datetime.today() - datetime.timedelta(1)
        end_day = start_day
    elif len(sys.argv)==2:
        start_day = datetime.datetime.strptime(sys.argv[1], "%Y-%m-%d")
        end_day = start_day
    elif len(sys.argv)==3:
        start_day = datetime.datetime.strptime(sys.argv[1], "%Y-%m-%d")
        end_day = datetime.datetime.strptime(sys.argv[2], "%Y-%m-%d")
    else:
        start_day = datetime.datetime.strptime(sys.argv[1], "%Y-%m-%d")
        end_day = datetime.datetime.strptime(sys.argv[2], "%Y-%m-%d")
        inDate = sys.argv[3]
    mode_day = []
    while start_day <= end_day:
        mode_day.append(start_day.strftime("%Y-%m-%d"))
        start_day = start_day + datetime.timedelta(1)
    spark = SparkSession.builder.master('yarn-client')\
        .appName('user_pref_day:' + inDate)\
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse')\
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    # 建表
    #create_user_pref(spark)
    item_profile = load_item_profile(spark)
    for md in mode_day:
        cal_index_day(spark, inDate, md, item_profile)
    spark.stop()


def cal_index_day(spark, inDate, act_day, item_profile):
    """统计用户的pref
    Args:
        inDate:用户对视频的偏好数据源：da.recy_als_data_uvm
        act_day:用户计算用户类别偏好的日期
        item_profile： 视频基础内容特征表
    Returs:
        diu:用户设备唯一id
        cate_pref:类别偏好
        cate_click_prob: 类别点击次数分布
        click_feature:用户视频点击内容特征向量
        total_num:总点击次数
        total_weight:总偏好
    """
    use_pref = load_user_pref_day(spark, inDate, act_day)
    user_item_pref = use_pref.join(item_profile, use_pref.u_vid == item_profile.vid, "inner")
    user_item_pref.persist()
    # 计算商品在用户群体的总数
    diu_item_nums = user_item_pref.groupby('u_diu','u_vid').agg(sf.count('*').alias('diu_vid_total'))
    item_nums = diu_item_nums.groupby('u_vid').agg(sf.count('*').alias('vid_total'))
    # 计算当天用户总数
    diu_nums = user_item_pref.groupby('u_diu').agg(sf.sum('f_rating').alias('diu_ratings'))
    global total_diu_nums
    total_diu_nums = diu_nums.count()
    item_nums = item_nums.withColumnRenamed('u_vid','vvid')
    diu_nums = diu_nums.withColumnRenamed('u_diu','diu')
    user_item_nums = user_item_pref.join(item_nums, user_item_pref.u_vid==item_nums.vvid,how='inner')\
        .join(diu_nums,user_item_pref.u_diu==diu_nums.diu,how='inner')
    user_item_pref.unpersist()
    # 按照品类统计用户的点击数及权重
    user_pref_num = user_item_nums.rdd.map(lambda x: [x['u_diu'], (x['pre_cate_id'], x['f_rating'], x['diu_ratings'], x['vid_total'], x['features'])])\
        .groupByKey().map(cal_cate_pref)
    user_prefDF= user_pref_num.map(lambda x:Row(diu= x[0], cate_pref=x[1], cate_click_prob=x[2], click_feature=x[3], \
                                           total_nums=x[4], total_weight=x[5], click_feature_nums=x[6]))
    user_pref_save = spark.createDataFrame(user_prefDF)
    user_pref_save.createOrReplaceTempView("user_pref")
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=1000"
    spark.sql(setSparSQLPartNum)
    pref_cols = ['diu', 'cate_pref', 'cate_click_prob', 'click_feature', 'total_nums', 'total_weight', 'click_feature_nums']
    save_sql = "insert overwrite table da.user_video_pref_day partition(dt='%s') select %s from user_pref" %(act_day, ",".join(pref_cols))
    spark.sql(save_sql)

def create_user_pref(spark):
    drop_sql = "drop table if exists da.user_video_pref_day"
    spark.sql(drop_sql)
    create_sql = "create table da.user_video_pref_day(diu string comment '设备id', \
    cate_pref string comment '用户点击类别偏好分布', \
    cate_click_prob string comment '用户点击类别个数分布', \
    click_feature string comment '用户视频内容特征向量', \
    total_nums bigint comment '用户当天点击个数', \
    total_weight double comment '用户当天总偏好', \
    click_feature_nums bigint comment '有效特征个数'), \
    partitioned by (dt string comment '分区日期') ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'"
    spark.sql(create_sql)


def cal_cate_pref(line):
    diu, diu_cate_pref = line
    total_num =0
    total_weight =0
    cate_pref = defaultdict(float)
    cate_click_prob = defaultdict(float)
    feature_size = 128
    total_features = np.zeros(feature_size)
    feature_num =0
    for pre_cate_id, f_rating, diu_ratings, vid_nums , features in diu_cate_pref:
        weight = f_rating* 1.0/(1 + diu_ratings) * math.log10((total_diu_nums+2) *1.0/ (1 + vid_nums))
        total_num +=1
        total_weight +=weight
        cate_pref[pre_cate_id] += weight
        cate_click_prob[pre_cate_id] +=1
        fv = features.strip().split(",")
        if len(fv)==feature_size:
            feature_num +=1
            total_features = total_features + np.array(map(lambda x: float(x), fv))
    #total_features = total_features*1.0/nn if nn!=0 else np.zeros(feature_size)
    click_feature = ",".join(map(lambda x: str(x), total_features.tolist()))
    # if total_num!=0:
    #     for cate,num in cate_click_prob.iteritems():
    #         cate_click_prob[cate] = num *1.0/total_num
    # if total_weight!=0:
    #     for cate,weight in cate_pref.iteritems():
    #         cate_pref[cate] = weight * 1.0 /total_weight
    cate_click_prob = json.dumps(dict(cate_click_prob), ensure_ascii=False)
    cate_pref = json.dumps(dict(cate_pref), ensure_ascii=False)
    return [diu, cate_pref, cate_click_prob, click_feature, total_num, total_weight, feature_num]


def load_user_pref(spark, dt):
    """获取最近一个月用户的偏好
    """
    sql = "select from_unixtime(f_timestamp, 'yyyy-MM-dd') mode_day, u_diu, u_vid, f_rating from da.recy_als_data_uvm where dt= '%s' " %(dt)
    user_pref = spark.sql(sql)
    return user_pref

def load_user_pref_day(spark, dt, act_day):
    """获取用户某一天的偏好
    """
    sql = "select from_unixtime(f_timestamp, 'yyyy-MM-dd') mode_day, u_diu, u_vid, f_rating \
          from da.recy_als_data_uvm where dt= '%s' and from_unixtime(f_timestamp, 'yyyy-MM-dd') = '%s'" %(dt, act_day)
    user_pref = spark.sql(sql)
    return user_pref

def load_item_profile(spark):
    sql="select cast(vid as string), pre_cate_id, prob, features from dw.lvcat"
    item_profile = spark.sql(sql)
    return item_profile


if __name__ == "__main__":
    main()


