#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/3/12 下午2:53'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'user_pref.py'
"""
import datetime
import sys
import numpy as np
import json
import datetime
from pyspark.sql import SQLContext
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
import pyspark.sql.functions as sf
import math
from collections import defaultdict
from pyspark.sql import Row
import argparse


PREF_COLUMNS = ['diu', 'cate_pref', 'cate_click_prob', 'click_feature', 'total_nums',\
                'total_weight','click_feature_nums','dt']
TOTAL_CATE = ["139", "145", "126", "136","130", "93", "112", "80", "85", "107", "122", "116"]
FEATURE_SIZE = 128
USER_PREF_COLUMNS =['diu', 'click_nums_month', 'click_weight_month','click_nums_three_month', 'click_weight_three_month', \
           'cate_click_prob_month_norm', 'cate_click_prob_three_month_norm', 'cate_pref_month_nrorm', \
           'cate_pref_three_month_norm', 'click_features_week', 'click_features_month', 'user_video_pref']

def main():
    global model_day
    inDate = (datetime.datetime.today() - datetime.timedelta(1)).strftime("%Y-%m-%d")
    # parser = argparse.ArgumentParser()
    # parser.add_argument("-s", "--start", help="start day", default=inDate)
    # parser.add_argument("-e", "--end", help="end day", default=inDate)
    # parser.add_argument("-m", "--model", help="model day", default=inDate)
    # args = parser.parse_args()
    # start_day = args.start
    # end_day = args.end
    # model_day = args.model
    if len(sys.argv)==1:
        end_day = inDate
        start_day = (datetime.datetime.strptime(end_day, "%Y-%m-%d") - datetime.timedelta(30)).strftime("%Y-%m-%d")
        model_day= end_day
    elif len(sys.argv)==2:
        end_day = sys.argv[1]
        start_day = (datetime.datetime.strptime(end_day, "%Y-%m-%d") - datetime.timedelta(30)).strftime("%Y-%m-%d")
        model_day = end_day
    elif len(sys.argv)==3:
        end_day = sys.argv[1]
        model_day = sys.argv[2]
        start_day = (datetime.datetime.strptime(end_day, "%Y-%m-%d") - datetime.timedelta(30)).strftime("%Y-%m-%d")
    else:
        start_day = sys.argv[1]
        model_day = sys.argv[2]
        end_day = sys.argv[3]
    spark = SparkSession.builder.master('yarn-client')\
        .appName('user_pref:' + inDate)\
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse')\
        .enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    user_pref = load_user_pref(spark, start_day, end_day)
    user_prefDF =user_pref.rdd.map(lambda x: [x[PREF_COLUMNS[0]], [x[i] for i in PREF_COLUMNS[1:]]])\
        .groupByKey().map(cal_user_pref)
    user_pref_save = spark.createDataFrame(user_prefDF)
    user_pref_save.createOrReplaceTempView("user_pref")
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=1000"
    spark.sql(setSparSQLPartNum)
    save_sql = "insert overwrite table da.user_video_pref partition(dt='%s') select %s from user_pref" \
               %(model_day, ",".join(USER_PREF_COLUMNS))
    spark.sql(save_sql)
    spark.stop()

def load_user_pref(spark, start_day, end_day):
    """加载用户兴趣
    """
    sql="select %s from da.user_video_pref_day where dt>='%s' and dt <= '%s' " %(",".join(PREF_COLUMNS), start_day, end_day)
    return spark.sql(sql)

def cal_user_pref(line):
    diu, profiles = line
    click_nums_month =0
    click_nums_three_month =0
    click_weight_month =0
    click_weight_three_month =0
    cate_pref_month = defaultdict(float)
    cate_click_prob_month = defaultdict(float)
    cate_pref_three_month = defaultdict(float)
    cate_click_prob_three_month = defaultdict(float)

    click_features_week = np.zeros(FEATURE_SIZE)
    click_features_month = np.zeros(FEATURE_SIZE)
    feature_nums_week = 0
    feature_nums_month = 0
    mode_day = datetime.datetime.strptime(model_day, "%Y-%m-%d")

    for cate_pref, cate_click_prob, features, day_num, day_weight, feature_num, dt in profiles:
        model_dt = datetime.datetime.strptime(dt, "%Y-%m-%d")
        delta =(mode_day - model_dt).days
        cate_pref = json.loads(cate_pref, encoding="utf-8")
        cate_click_prob = json.loads( cate_click_prob, encoding="utf-8")
        day_weight = day_weight*1.0 * math.exp(-0.024 * (delta + 1))
        if delta <=30:
            click_nums_month += day_num
            click_weight_month += day_weight
        if delta <=90:
            click_nums_three_month += day_num
            click_weight_three_month += day_weight
        for cate, prob in cate_click_prob.iteritems():
            if delta <= 30:
                cate_click_prob_month[cate] += prob
            if delta <= 90:
                cate_click_prob_three_month[cate] += prob
        for cate, pref in cate_pref.iteritems():
            if delta <= 30:
                cate_pref_month[cate] += pref *1.0* math.exp(-0.024 * (delta + 1))
            if delta <= 90:
                cate_pref_three_month[cate] += pref *1.0* math.exp(-0.024 * (delta + 1))
        # 图像最近一周及一个月的特征
        fv = features.strip().split(",")
        if len(fv)==FEATURE_SIZE:
            if delta <=7:
                feature_nums_week +=feature_num
                click_features_week = click_features_week + np.array(map(lambda x: float(x), fv))
            if delta <= 30:
                feature_nums_month +=feature_num
                click_features_month = click_features_month + np.array(map(lambda x: float(x), fv))
    cate_click_prob_month = norm_pref(cate_click_prob_month, click_nums_month)
    cate_click_prob_three_month = norm_pref(cate_click_prob_three_month, click_nums_three_month)
    cate_pref_month=norm_pref(cate_pref_month, click_weight_month)
    cate_pref_three_month = norm_pref(cate_pref_three_month, click_weight_three_month)
 
    cate_click_prob_month_norm = json.dumps(dict(cate_click_prob_month), ensure_ascii=False)
    cate_click_prob_three_month_norm = json.dumps(dict(cate_click_prob_three_month), ensure_ascii=False)
    cate_pref_month_nrorm = json.dumps(dict(cate_pref_month), ensure_ascii=False)
    cate_pref_three_month_norm = json.dumps(dict(cate_pref_three_month), ensure_ascii=False)
    click_features_week = click_features_week*1.0/feature_nums_week if feature_nums_week!=0 else np.zeros(FEATURE_SIZE)
    click_features_week = ",".join(map(lambda x: str(x), click_features_week.tolist()))
    click_features_month = click_features_month*1.0/feature_nums_month if feature_nums_month!=0 else np.zeros(FEATURE_SIZE)
    click_features_month = ",".join(map(lambda x: str(x), click_features_month.tolist()))
    user_video_pref = map(lambda x: format_pref(x), [cate_click_prob_month, cate_click_prob_three_month, \
                                             cate_pref_month, cate_pref_three_month])
    user_video_pref.append(click_features_week)
    user_video_pref.append(click_features_month)
    user_features = ",".join(user_video_pref)
    return Row(diu=diu, click_nums_month=click_nums_month, \
                click_weight_month=click_weight_month, \
                click_nums_three_month=click_nums_three_month, \
                click_weight_three_month=click_weight_three_month, \
                cate_click_prob_month_norm=cate_click_prob_month_norm, \
                cate_click_prob_three_month_norm=cate_click_prob_three_month_norm, \
                cate_pref_month_nrorm=cate_pref_month_nrorm, \
                cate_pref_three_month_norm=cate_pref_three_month_norm, \
                click_features_week=click_features_week, \
                click_features_month=click_features_month, \
                user_video_pref = user_features)
 

def norm_pref(cate_pref, nums):
    cate_pref_norm = dict()
    if nums!=0 and len(cate_pref.keys()) >0:
        for cate, pref in cate_pref.iteritems():
            cate_pref_norm[cate] = pref *1.0/nums
        return cate_pref_norm
    else:
        return cate_pref

def format_pref(cate_pref):
    out=[]
    for cate in TOTAL_CATE:
        out.append(cate_pref.get(cate, 0))
    return ",".join(map(str, out))

def create_user_pref(spark):
    drop_sql = "drop table if exists da.user_video_pref"
    spark.sql(drop_sql)
    create_sql = "create table da.user_video_pref(\
    diu string comment '设备id', \
    click_nums_month bigint comment '用户最近1月点击数', \
    click_weight_month double comment '用户最近1月兴趣值', \
    click_nums_three_month bigint comment '用户最近3月点击数', \
    click_weight_three_month double comment '用户最近3月兴趣值', \
    cate_click_prob_month_norm string comment '用户最近1月点击类别分布', \
    cate_click_prob_three_month_norm string comment '用户最近3月点击类别分布',\
    cate_pref_month_nrorm string comment '用户最近1月兴趣类别分布',\
    cate_pref_three_month_norm string comment '用户最近3月兴趣类别分布',\
    click_features_week string comment '用户最近一周视频深度特征', \
    click_features_month string comment '用户最近一月视频深度特征', \
    user_video_pref string  comment '用户对视频的偏好特征')\
    partitioned by (dt string comment '分区日期') ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'"
    spark.sql(create_sql)

if __name__ == "__main__":
    main()



