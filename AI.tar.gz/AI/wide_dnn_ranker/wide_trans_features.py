#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2018/01/04 上午10:25'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'wide_trans_features.py'
"""
import json
import datetime
from pyspark.sql import SQLContext
from pyspark.sql.types import DoubleType
from pyspark.sql.types import LongType
from pyspark.sql.functions import udf
from pyspark import SparkContext, SparkConf
from pyspark.sql import Window
from pyspark.sql.functions import percent_rank
from pyspark.sql import Row, SparkSession
import math
from pyspark.ml.feature import VectorAssembler, StringIndexer, OneHotEncoder
from pyspark.sql.functions import log1p
import util
import sys

UGC_FEATURES_DIR = "hdfs://Ucluster/olap/da/kol_score_uid_raw_feature/dt="
VIDEO_FEATURES_DIR = "hdfs://Ucluster/olap/da/recy_raw_itfeature/"
UERS_FEATURES_DIR = "hdfs://Ucluster/olap/da/recy_raw_usfeature/"
FEATURE_REAGE_DIR = "hdfs://Ucluster/olap/da/wide_dl/range/"
VIDEO_FEATURES_TRAN = "hdfs://Ucluster/olap/da/wide_dl/tran_itfeature/"
UERS_FEATURES_TRAN = "hdfs://Ucluster/olap/da/wide_dl/tran_usfeature/"

VIDEO_FEATURES_REDIS = "hdfs://Ucluster/olap/da/wide_dl/it_redis/"
UERS_FEATURES_REDIS = "hdfs://Ucluster/olap/da/wide_dl/us_redis/"

ugc_numeric = util.ugc_numeric
video_numeric = util.video_numeric
video_cate = util.video_cate
video_id = util.video_id

user_numeric = util.user_numeric
user_cate =util.user_cate
user_id = util.user_id

user_pref_numeric = util.user_pref_numeric
com_user_features = util.com_user_features
item_profile_numeric = util.item_profile_numeric
item_profile_cate = util.item_profile_cate
com_item_features = util.com_item_features

item_profile_col = item_profile_numeric + item_profile_cate + com_item_features
user_profile_col = user_pref_numeric + com_user_features

# 所有训练特征
model_features  = util.get_all_features()[1:]


def main():
    if len(sys.argv) == 1:
        inDates = [(datetime.datetime.today() -datetime.timedelta(1)).strftime("%Y-%m-%d")]
    elif len(sys.argv) == 2:
        inDates= [sys.argv[1]]
    else:
        start_day = datetime.datetime.strptime(sys.argv[1],"%Y-%m-%d")
        end_day= datetime.datetime.strptime(sys.argv[2],"%Y-%m-%d")
        inDates = []
        while start_day<= end_day:
            inDates.append(start_day.strftime("%Y-%m-%d"))
            start_day = start_day+datetime.timedelta(1)
    spark = SparkSession.builder.master('yarn-client')\
        .appName('features_transform:')\
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse')\
        .enableHiveSupport().getOrCreate()
    for inDate in inDates:
        get_transfrom_features(spark, "user", inDate)
        get_transfrom_features(spark, "video", inDate)
    spark.stop()

def get_transfrom_features(spark, user_video_flag, inDate):
    sc = spark.sparkContext
    if user_video_flag=="user":
        user_video_dir = UERS_FEATURES_DIR + inDate
        numeric_features = user_numeric + user_pref_numeric
        cate_featuers = user_cate
        feature_range_dir = FEATURE_REAGE_DIR + "user/" + inDate
        idfeatures = user_id + com_user_features
        is_log = False
    elif user_video_flag=="video":
        user_video_dir = VIDEO_FEATURES_DIR + inDate
        numeric_features = video_numeric + ugc_numeric + item_profile_numeric
        cate_featuers = video_cate + item_profile_cate
        feature_range_dir = FEATURE_REAGE_DIR + "video/" + inDate
        idfeatures= video_id + com_item_features
        is_log =True
    user_video_raw = load_features(spark, user_video_dir, inDate, user_video_flag)
    #feature_range = get_describe(spark, user_video_raw, numeric_features, feature_range_dir, is_log)
    feature_range = load_describe(spark, user_video_flag, "2018-03-10")
    trans_DF = video_user_Tran_v2(user_video_flag, idfeatures, numeric_features, cate_featuers, user_video_raw, feature_range, is_log)
    save_model_redis(trans_DF, user_video_flag, inDate, to_redis=False)


def save_model_redis(trans_DF, user_video_flag, inDate, to_model=True, to_redis=False):
    """libsvm格式输出特征
    """
    if user_video_flag =="video":
        save_redis_dir = VIDEO_FEATURES_REDIS + inDate
        save_model_dir = VIDEO_FEATURES_TRAN + inDate
        features = util.get_it_features()
    else:
        save_redis_dir = UERS_FEATURES_REDIS+inDate
        save_model_dir = UERS_FEATURES_TRAN + inDate
        features = util.get_us_features()
    trans_DF.createOrReplaceTempView(user_video_flag +"_features")
    if to_model:
        trans_DF.write.mode('overwrite').save(save_model_dir, format="parquet")
    if to_redis:
        if user_video_flag =="video":
            trans_DF = trans_DF.withColumn("vid_key", trans_DF["vid"])
            vid_key = ["vid_key"]
            vid_key.extend(features)
            features = list(vid_key)
        trans_DF.select(features).write.mode('overwrite')\
            .save(save_redis_dir, format="csv")




def load_features(spark, user_video_dir, inDate, user_video_flag='user'):
    """加载数据
    """
    user_video = spark.read.load(user_video_dir)
    if user_video_flag=="user":
        return merge_profile(spark, user_video, inDate, user_video_flag)
    else:
        video_ugc_data = merge_ugc_features(spark, user_video, inDate)
        return merge_profile(spark, video_ugc_data, inDate, user_video_flag)

def merge_profile(spark, user_video_DF, inDate, user_video_flag):
    """合并视频，用户特征数据
    """
    proflie_na_value = get_profile_na(user_video_flag)
    if user_video_flag == "video":
        profile_DF = load_item_profile(spark, inDate)
        user_profile_DF = user_video_DF.join(profile_DF, 'vid', 'left_outer').na.fill(proflie_na_value)
    else:
        profile_DF = load_user_profile(spark, inDate)
        user_profile_DF = user_video_DF.join(profile_DF, 'diu', 'left_outer').na.fill(proflie_na_value)
    return user_profile_DF

def load_item_profile(spark, inDate):
    """加载视频特征
    """
    col_names = ['vid'] + item_profile_col
    sql = "select %s from dw.lvcat " %(",".join(col_names))
    return spark.sql(sql)

def load_user_profile(spark, inDate):
    col_names = ['diu'] + user_profile_col
    sql = "select %s from da.user_video_pref where dt='%s' " %(",".join(col_names), inDate)
    return spark.sql(sql)

def merge_ugc_features(spark, video_raw, inDate):
    """合并视频作者的特征数据
    """
    ugc_sql = "select uid, %s from da.kol_score_uid_raw_feature where dt='%s' and type= 10" %(",".join(ugc_numeric), inDate)
    ugc_features = spark.sql(ugc_sql)
    video_ugc_features = video_raw.join(ugc_features, 'uid', 'left_outer').na.fill(0.0)
    return video_ugc_features

def get_profile_na(user_video_flag):
    """获取profile的默认值
    """
    default_value = dict()
    col_names = item_profile_col if user_video_flag == "video" else user_profile_col
    com_features_all = com_user_features + com_item_features
    for col_name in col_names:
        if col_name in com_features_all:
            col_len = util.com_features.get(col_name)
            value = ",".join(['0' for i in range(col_len)])
            default_value[col_name] = value
        elif col_name in item_profile_cate:
            default_value[col_name] = '0'
        else:
            default_value[col_name] = 0
    return default_value


def load_percentile(spark, user_video_flag):
    if user_video_flag =="video":
        feature_range_dir = "hdfs://Ucluster/olap/da/wide_dl/range/video/2017-12-17"
    else:
        feature_range_dir = "hdfs://Ucluster/olap/da/wide_dl/range/user/2017-12-17"
    sc = spark.sparkContext
    feature_range = sc.textFile(feature_range_dir, 1).map(lambda x: x.strip().encode("utf-8").split("\t")).collect()
    feature_range_dict={}
    for cate, min_a, max_a in feature_range:
        feature_range_dict[cate] = [float(min_a), float(max_a)]
    return feature_range_dict

def get_percentile(spark, raw_features_data, numeric_features, feature_range_dir):
    """获取feed_back反馈数据
    """
    raw_features_sample = raw_features_data
    #raw_features_sample = raw_features_data.sample(False, 0.5)
    max_index = ["max" for i in range(len(numeric_features))]
    min_index = ["min" for i in range(len(numeric_features))]
    max_feature = list(raw_features_sample.agg(dict(zip(numeric_features, max_index))).collect()[0])
    min_feature = list(raw_features_sample.agg(dict(zip(numeric_features, min_index))).collect()[0])
    feature_range = []
    for i in range(len(numeric_features)):
        feature_range.append([numeric_features[i], [max(min_feature[i], 0), max_feature[i]]])
    sc=spark.sparkContext
    sc.parallelize(feature_range).map(lambda x: "\t".join(map(str, [x[0], x[1][0], x[1][1]])))\
        .repartition(1)\
        .saveAsTextFile(feature_range_dir)
    return dict(feature_range)

def load_describe(spark, user_video_flag, dt):
    if user_video_flag =="video":
        feature_range_dir = "hdfs://Ucluster/olap/da/wide_dl/range/video/" + dt
    else:
        feature_range_dir = "hdfs://Ucluster/olap/da/wide_dl/range/user/" + dt
    sc = spark.sparkContext
    feature_range = sc.textFile(feature_range_dir, 1).map(lambda x: x.strip().encode("utf-8")).collect()
    feature_range_dict=json.loads(feature_range[0])
    return feature_range_dict

#def get_describe(spark, raw_features_data, numeric_features, feature_range_dir, is_log):
#    feature_range = dict()
#    for i in range(len(numeric_features)):
#        if is_log:
#            raw_features_data = raw_features_data.withColumn(numeric_features[i], log1p(numeric_features[i]))
#        raw_features = raw_features_data.select([numeric_features[i]]).describe().rdd.map(lambda x:[x[0], x[1]]).collectAsMap()
#        feature_range[numeric_features[i]] = raw_features
#    sc=spark.sparkContext
#    sc.parallelize([json.dumps(feature_range,ensure_ascii=False)], 1)\
#        .repartition(1)\
#        .saveAsTextFile(feature_range_dir)
#    return feature_range

def get_describe(spark, raw_features_data, numeric_features, feature_range_dir, is_log):
    feature_range = dict()
    for i in range(len(numeric_features)):
        if is_log:
            raw_features_data = raw_features_data.withColumn(numeric_features[i], log1p(numeric_features[i]))
    index =['summary'] + numeric_features
    features_values = raw_features_data.select(numeric_features).describe().rdd.map(lambda x:[x[i] for i in index]).collect()
    for value in features_values:
        index_one = value[0]
        index_value = value[1:]
        for i in range(len(numeric_features)):
            k, v = index_one, index_value[i]
            if numeric_features[i] not in feature_range.keys():
                feature_range[numeric_features[i]] = dict()
            feature_range[numeric_features[i]][k] = v
    sc=spark.sparkContext
    sc.parallelize([json.dumps(feature_range,ensure_ascii=False)], 1)\
        .repartition(1)\
        .saveAsTextFile(feature_range_dir)
    return feature_range


def Tran_video_user(user_item_flag, idlist, numericList, cateList, df):
    id = 'diu' if user_item_flag =='user' else 'vid'
    vecList = list()
    for raw in idlist:
        vecList.append(raw)
    for raw in numericList:
        window = Window.orderBy(raw).partitionBy()
        df_r = df.select([id, raw]).withColumn(raw+"_vec", percent_rank().over(window))
        df = df.join(df_r, id, 'inner')
        vecList.append(raw+"_vec")
    for raw in cateList:
        vecList.append(raw)
    return df.select(vecList)

def video_user_Tran(user_item_flag, idlist, numericList, cateList, df, feature_range, is_log):
    def max_min(x, x_range):
        amin, amax = x_range
        return (x-amin) *1.0/(amax - amin)
    def log_max_min(x, x_range):
        amin, amax = x_range
        amin = max(amin, 0)
        x = max(x, 0)
        return (math.log(1+x) - math.log(1 + amin))*1.0/(math.log(1 + amax) -math.log (1 + amin))
    def max_min_tf(x_range):
        return udf(lambda c: max_min(c, x_range), DoubleType())
    def log_max_min_tf(x_range):
        return udf(lambda c: log_max_min(c, x_range), DoubleType())
    numeric_tf = max_min_tf if is_log else log_max_min_tf
    flag = 'us_' if user_item_flag =='user' else 'it_'
    vecList = list()
    for raw in idlist:
        vecList.append(raw)
    for raw in numericList:
        min_max_feature = feature_range.get(raw)
        df = df.withColumn(raw, numeric_tf(min_max_feature)(raw))
        vecList.append(raw)
    for raw in cateList:
        vecList.append(raw)
    return df.select(vecList)

def video_user_Tran_v2(user_item_flag, idlist, numericList, cateList, df, feature_range, is_log):
    def max_min(x, x_range):
        indexs = x_range.get("min", 0), x_range.get("max", 0), x_range.get("mean", 0), x_range.get("stddev", 0)
        indexs = map(lambda x: float(x), indexs)
        amin, amax, amean, astd = indexs
        bmin = (amin-amean)*1.0/astd
        bmax = (amax-amean)*1.0/astd
        x = (x-amean)*1.0/astd
        return (x-bmin) *1.0/(bmax - bmin)
    def log_max_min(x, x_range):
        indexs = x_range.get("min", 0), x_range.get("max", 0), x_range.get("mean", 0), x_range.get("stddev", 0)
        indexs = map(lambda x: float(x), indexs)
        amin, amax, amean, astd = indexs
        bmin = (amin-amean)*1.0/astd
        bmax = (amax-amean)*1.0/astd
        x = (math.log1p(max(x,0))-amean)*1.0/astd
        return (x-bmin) *1.0/(bmax - bmin)
    def max_min_tf(x_range):
        return udf(lambda c: max_min(c, x_range), DoubleType())
    def log_max_min_tf(x_range):
        return udf(lambda c: log_max_min(c, x_range), DoubleType())
    numeric_tf = log_max_min_tf if is_log else max_min_tf
    flag = 'us_' if user_item_flag =='user' else 'it_'
    vecList = list()
    for raw in idlist:
        vecList.append(raw)
    for raw in numericList:
        min_max_feature = feature_range.get(raw)
        df = df.withColumn(raw, numeric_tf(min_max_feature)(raw))
        vecList.append(raw)
    for raw in cateList:
        vecList.append(raw)
    return df.select(vecList)




if __name__ =="__main__":
    main()


