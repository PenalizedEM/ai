#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2017/12/5 下午5:58'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'util.py'
"""
video_numeric = ["hits_total", "comment_total", "SHARE","fav_count", "flower_uv", \
               "onedayctr", "onedayclick", "onedaygood", "onedaycomment", "onedayshare", \
               "allctr", "sevendayctr", "sevendayclick", "sevendaygood", "sevendaycomment",\
               "sevendayshare", "duration", "createhour", "u_exavgtime", "u_exavgpre"]

video_cate = ["TYPE", "child_category", "degree", "genre", "parent_category"]

video_id = ["uid", "vid"]

user_numeric = ["comments","shares", "likes", "u_wvdur", "u_wvcnts", "u_fresh", "u_active", \
                "starts", "lite_avg_pt", "normal_avg_pt", "lite_avg_cnt", \
                "normal_avg_cnt", "lite_avg_ctr", "normal_avg_ctr", "rsource1_ctr", "rsource14_ctr", \
                "rsource15_ctr"]

user_cate = ["u_act_status", "u_actperiod", "u_citylevel", "u_cc", "u_cc2", "u_osv", "u_client", \
             "dv_cm1", "dv_cm2", "vv_cm1", "vv_cm2"]
user_id = ["diu", "f_diu"]

not_use = ["d_rsource", "d_rank", "d_ruuid", "m_dv", "coderate", "definition", "createtime", "u_city_abcode"]

ugc_numeric = ['total_cnt','oneday_cnt','sevenday_cnt','thirtyday_cnt',\
               #'sum_ufav','max_ufav','mean_ufav',\
               #'oneday_sum_ufav','oneday_max_ufav','oneday_mean_ufav','sevenday_sum_ufav','sevenday_max_ufav',\
               #'sevenday_mean_ufav','thirtyday_sum_ufav','thirtyday_max_ufav','thirtyday_mean_ufav',\
               'sum_ugood', 'max_ugood','mean_ugood','oneday_sum_ugood','oneday_max_ugood','oneday_mean_ugood','sevenday_sum_ugood',\
               'sevenday_max_ugood','sevenday_mean_ugood','thirtyday_sum_ugood','thirtyday_max_ugood','thirtyday_mean_ugood',\
               'sum_ucmt','max_ucmt','mean_ucmt','oneday_sum_ucmt','oneday_max_ucmt','oneday_mean_ucmt','sevenday_sum_ucmt',\
               'sevenday_max_ucmt','sevenday_mean_ucmt','thirtyday_sum_ucmt','thirtyday_max_ucmt','thirtyday_mean_ucmt',\
               'sum_ushare','max_ushare','mean_ushare','oneday_sum_ushare','oneday_max_ushare','oneday_mean_ushare',\
               'sevenday_sum_ushare','sevenday_max_ushare','sevenday_mean_ushare','thirtyday_sum_ushare','thirtyday_max_ushare',\
               'thirtyday_mean_ushare','sum_pt','max_pt','mean_pt','oneday_sum_pt','oneday_max_pt','oneday_mean_pt',\
               'sevenday_sum_pt','sevenday_max_pt','sevenday_mean_pt','thirtyday_sum_pt','thirtyday_max_pt','thirtyday_mean_pt',\
               'sum_uv','max_uv','mean_uv','oneday_sum_uv','oneday_max_uv','oneday_mean_uv','sevenday_sum_uv',\
               'sevenday_max_uv','sevenday_mean_uv','thirtyday_sum_uv','thirtyday_max_uv','thirtyday_mean_uv','sum_udv',\
               'max_udv','mean_udv','oneday_sum_udv','oneday_max_udv','oneday_mean_udv','sevenday_sum_udv','sevenday_max_udv',\
               'sevenday_mean_udv','thirtyday_sum_udv','thirtyday_max_udv','thirtyday_mean_udv','mean_ctr','max_ctr',\
               'oneday_max_ctr','oneday_mean_ctr','sevenday_max_ctr','sevenday_mean_ctr','thirtyday_max_ctr','thirtyday_mean_ctr']

user_pref_numeric = ['click_nums_month', 'click_weight_month', 'click_nums_three_month', 'click_weight_three_month']
com_user_features = ['video_pref']
item_profile_numeric = ['prob']
item_profile_cate =['pre_cate_id']
com_item_features = ['features']
com_features = {'features': 128, 'video_pref': 304}

label = ['label']

TOTAL_CATE = ["139", "145", "126", "136","130", "93", "112", "80", "85", "107", "122", "116", "0"]

def build_category_dict():
    category_dict=dict()
    category_dict['u_act_status'] = map(str, range(12))
    category_dict['u_citylevel'] = map(str, range(9))
    category_dict['u_actperiod'] = map(str, range(9))
    category_dict['u_osv'] = map(str, range(4))
    category_dict['u_client'] = map(str, range(4))
    category_dict['pre_cate_id'] = TOTAL_CATE
    return category_dict


def get_all_features(need_change_type=False):
    """建模数据不使用diu，diu用来关联反馈数据
    """
    us_features = get_us_features()
    it_features= get_it_features()
    features = us_features
    features.extend(it_features)
    # type字段跟tf定义冲突，需要重新命名
    if need_change_type:
        features = change_col(features)
    return features

def get_us_features():
    """建模的视频特征
    """
    features = list(user_id)
    features.extend(user_cate)
    features.extend(user_numeric)
    # 用户pref
    features.extend(user_pref_numeric)
    features.extend(com_user_features)
    return features


def get_it_features():
    """建模的用户特征
    """
    features=list(video_id)
    features.extend(video_cate)
    features.extend(video_numeric)
    # ugc features
    features.extend(ugc_numeric)
    # item deep vector
    features.extend(item_profile_numeric)
    features.extend(item_profile_cate)
    features.extend(com_item_features)
    return features

def change_col(features):
    for index, name in enumerate(features):
        if name == "TYPE":
            features[index] = "ttype"
    return features

def search_ft_index(feature):
    """查找feature在特征里面的索引
    """
    features_model = get_all_features()[1:]
    for index, feature_name in enumerate(features_model):
        if feature_name == feature:
            return index


def get_cate_index():
    """获取特征里面的类别变量索引
    """
    features_model = format_all_features()[1:]
    cate_all = set(user_cate)|set(video_cate)|set(item_profile_cate)
    cate_index = []
    for index, feature_name in enumerate(features_model):
        if feature_name in cate_all:
            cate_index.append(index)
    return cate_index



def format_all_features(need_change_type=False):
    """索引所有的特征
    """
    all_features = get_all_features(need_change_type)
    format_features = []
    for feature in all_features:
        if feature in com_features.keys():
            com_features_len = com_features[feature]
            com_features_add = ["_".join([feature, str(i)]) for i in range(com_features_len)]
            format_features.extend(com_features_add)
        else:
            format_features.append(feature)
    return format_features



def get_feature_default():
    """设置label,特征的默认值
    """
    # label+特征总数
    label_features_dim = len(format_all_features())
    default_value = [[0.0] for i in range(label_features_dim)]
    cate_index = get_cate_index()
    for index in cate_index:
        default_value[index + 1] =['0']
    return default_value


