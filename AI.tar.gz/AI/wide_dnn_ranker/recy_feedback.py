#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : '2017/12/1 上午11:25'
@Author  : 'caoyongchuang(caoyc@tangdou.com)'
@File    : 'recy_feedback.py'
"""
import datetime
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
import sys
reload(sys)
sys.setdefaultencoding("utf-8")

VIDEO_FEATURES_TRAN = "hdfs://Ucluster/olap/da/wide_dl/tran_itfeature/"
UERS_FEATURES_TRAN = "hdfs://Ucluster/olap/da/wide_dl/tran_usfeature/"

LABEL_FEATURE = "hdfs://Ucluster/olap/da/wide_dl/feed_back/"

def main():
    if len(sys.argv) == 1:
        inDates = [(datetime.datetime.today() -datetime.timedelta(1)).strftime("%Y-%m-%d")]
    elif len(sys.argv) == 2:
        inDates= [sys.argv[1]]
    else:
        start_day = datetime.datetime.strptime(sys.argv[1],"%Y-%m-%d")
        end_day= datetime.datetime.strptime(sys.argv[2],"%Y-%m-%d")
        inDates = []
        while start_day<= end_day:
            inDates.append(start_day.strftime("%Y-%m-%d"))
            start_day = start_day+datetime.timedelta(1)
    spark = SparkSession.builder.master('yarn-client')\
        .appName('recy_feedback:')\
        .config('spark.sql.warehouse.dir', '/user/hive/warehouse')\
        .enableHiveSupport().getOrCreate()
    for inDate in inDates:
        exclick_data = get_exclick(spark, inDate)
        video_features = load_features(spark, VIDEO_FEATURES_TRAN, inDate)
        user_features = load_features(spark, UERS_FEATURES_TRAN, inDate)
        label_features = exclick_data.join(video_features, 'vid','inner')\
            .join(user_features, 'diu', 'inner')
        label_features.createOrReplaceTempView('label_features')
        save_dir = LABEL_FEATURE + inDate
        label_features.write.mode('overwrite').save(save_dir, format="parquet")
    spark.stop()

def get_exclick(spark, inDate, is_filter_short=True):
    """获取曝光数据
    """
    exclickSQL = "SELECT a.d_diu diu, a.d_vid vid, if(b.m_vv IS NULL ,0,1) label, a.d_rsource d_rsource,\
            a.d_rank d_rank, a.d_ruuid d_ruuid,if(a.m_dv IS NULL,0,a.m_dv) m_dv \
                  FROM (SELECT d_diu, d_vid, d_rsource, d_rank, d_ruuid, sum(m_dv) m_dv \
                    FROM adm.f_new_video_dv WHERE dt= '%s' \
                    AND d_module IN ('推荐流', '推荐', '每日推荐', '猜你喜欢', '首页推荐流') \
                    AND d_diu <> '-'GROUP BY d_diu, d_vid, d_rsource, d_rank, d_ruuid)a \
                  LEFT OUTER JOIN (SELECT d_diu, d_vid, d_rsource, d_rank, d_ruuid, sum(m_vv) m_vv \
                  FROM adm.f_new_video_vv WHERE dt= '%s' \
                  AND d_module IN ('推荐流', '推荐', '每日推荐', '猜你喜欢', '首页推荐流') \
                  AND d_diu <> '-'GROUP BY d_diu, d_vid, d_rsource, d_rank, d_ruuid)b \
                  ON (a.d_diu= b.d_diu AND a.d_vid=b.d_vid AND a.d_ruuid= b.d_ruuid) \
                  GROUP BY a.d_diu, a.d_vid, a.d_rsource, a.d_rank, a.d_ruuid, a.m_dv, b.m_vv" %(inDate, inDate)
    exclickDF = spark.sql(exclickSQL).select(['diu', 'vid', 'label'])
    if is_filter_short:
        short_video_sql= "select vid from dw.video where status <> 5 and type=10"
        short_video = spark.sql(short_video_sql)
        exclickDF = exclickDF.join(short_video,'vid','inner')
    return exclickDF



def load_features(spark, user_video_dir, inDate):
    """加载数据
    """
    return spark.read.load(user_video_dir + inDate)

if __name__ == "__main__":
    main()

