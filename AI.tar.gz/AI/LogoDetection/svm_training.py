#!/usr/bin/python
#coding:utf-8


from hog import Hog_descriptor
import cv2
import numpy as np
import matplotlib.pyplot as plt
from sklearn import svm
import os.path
import math
from sklearn.externals import joblib

path_neg = '/Users/lilin/workspace_python/ocr_similarity/neg/'

# 火山小视频
# height_std = 40
# width_std = 150
# size_std = (width_std, height_std)
# path_huo = '/Users/lilin/workspace_python/ocr_similarity/huo_pos/'
# model_huo = '/Users/lilin/workspace_python/ocr_similarity/huo1206.m'
# 抖音
height_std = 20
width_std = 40
size_std = (width_std, height_std)
path_douyin = '/Users/lilin/workspace_python/ocr_similarity/douyin_pos/'
model_douyin = '/Users/lilin/workspace_python/ocr_similarity/douyin1206.m'



path = path_douyin
model = model_douyin
img_data_pos = []
img_list = os.listdir(path)
for img in img_list:
	if '.png' in img:
		try:
			input_img = cv2.imread(path + img, cv2.IMREAD_GRAYSCALE)
			input_img = cv2.resize(input_img, size_std)
			hog = Hog_descriptor(input_img, cell_size=8, bin_size=8)
			vector, image = hog.extract()
		except IOError:
			print 'hog失败:', path + img
		img_data_pos.append(vector)
	

img_data_neg = []
img_list = os.listdir(path_neg)
for img in img_list:
	if '.png' in img:
		try:
			input_img = cv2.imread(path_neg + img, cv2.IMREAD_GRAYSCALE)
			sp = input_img.shape
			h = sp[0]  # height
			w = sp[1]  # width
			step = 180
			for i in range(1, w, step):
				for j in range(1, h, step):
					if j + height_std < h and i + width_std < w:
						box = input_img[j:j + height_std, i:i + width_std]
						hog = Hog_descriptor(box, cell_size=8, bin_size=8)
						vector, image = hog.extract()
						img_data_neg.append(vector)
		except IOError:
			print 'hog失败:', path + img

		
# X = [[0, 0], [1, 1], [1, 0]]  # training samples
# y = [0, 1, 1]  # training target
# clf = svm.SVC()  # class
# clf.fit(X, y)  # training the svc model
# a = [[2, 2]]
# result = clf.predict(a)  # predict the target of testing samples
# print result  # target
# print clf.support_vectors_  # support vectors
# print clf.support_  # indeices of support vectors
# print clf.n_support_  # number of support vectors for each class
# svm = cv2.SVM()
# svm.train()


# label
label_pos = [1] * len(img_data_pos)
label_neg = [0] * len(img_data_neg)
label_pos.extend(label_neg)
y = label_pos
# training samples
img_data_pos.extend(img_data_neg)
x = img_data_pos
# classocr_similarity/svm_run_online.py:62
clf = svm.SVC(kernel='rbf')
# training the svc model
clf.fit(x, y)
# save model
joblib.dump(clf, model)
print 'ok'
# predict the target of testing samples
# result = clf.predict([[2, 2]])
# target
# print result
# support vectors
# print clf.support_vectors_
# indeices of support vectors
# print clf.support_
# number of support vectors for each class
# print clf.n_support_