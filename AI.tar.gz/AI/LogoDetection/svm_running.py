#!/usr/bin/python
#coding:utf-8


from hog import Hog_descriptor
import cv2
import numpy as np
import matplotlib.pyplot as plt
from sklearn import svm
import os.path
import math
from sklearn.externals import joblib
from PIL import Image
import datetime
from sklearn.metrics import accuracy_score

scale = 0.25

# 火山小视频
# height_std = 40
# width_std = 150
# size_std = (width_std, height_std)
# model_huo = '/Users/lilin/workspace_python/ocr_similarity/huo1206.m'
# scale = 0.25
# 抖音
height_std = 35
width_std = 55
height_std2 = 30
width_std2 = 50
height_scale = 20
width_scale = 40
size_std = (width_std, height_std)
size_scale = (width_scale, height_scale)
model_douyin = '/Users/lilin/workspace_python/ocr_similarity/douyin1206.m'


model_path = model_douyin
CLASSFIER = svm.SVC()
CLASSFIER = joblib.load(model_path)


path = '/Users/lilin/workspace_python/ocr_similarity/douyin/WechatIMG80.jpeg'
img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
img_color = cv2.imread(path)
sp = img.shape
h = sp[0]  # height
w = sp[1]  # width
step = 2
tst_data = []
# 火山小视频
height_up = int(h * scale)
height_top = int(h * (1-scale))
num = 0
num_hit = 0


def detecting(img):
	sp = img.shape
	h = sp[0]  # height
	w = sp[1]  # width
	step = 5
	tst_data = []
	height_up = int(h * 0.25)
	height_top = int(h * 0.75)
	num_hit = 0
	
	for i in range(1, w, step):
		for j in range(1, h, step):
			
			flag = 0
			if j + height_std < height_up or j > height_top:
				flag = 1
			
			if j + height_std < h and i + width_std < w and flag == 1:
				box = img[j:j + height_std, i:i + width_std]
				hog = Hog_descriptor(box, cell_size=8, bin_size=8)
				vector, image = hog.extract()
				tst_data.append(vector)
				res = CLASSFIER.predict(tst_data)
				tst_data = []
				if res[0] == 1:
					num_hit += 1
				
				box = img[j:j + height_std2, i:i + width_std2]
				hog = Hog_descriptor(box, cell_size=8, bin_size=8)
				vector, image = hog.extract()
				tst_data.append(vector)
				res = CLASSFIER.predict(tst_data)
				tst_data = []
				if res[0] == 1:
					num_hit += 1
					
				if num_hit == 3:
					break
		if num_hit == 3:
			break
	return num_hit

starttime = datetime.datetime.now()

for i in range(1, w, step):
	for j in range(1, h, step):

		flag = 0
		if j + height_std < height_up or j > height_top:
			flag = 1

		if j + height_std < h and i + width_std < w and flag == 1:
			box = img[j:j + height_std, i:i + width_std]
			box_scale = cv2.resize(box, size_scale)
			hog = Hog_descriptor(box_scale, cell_size=8, bin_size=8)
			vector, image = hog.extract()
			tst_data.append(vector)
			res = CLASSFIER.predict(tst_data)
			tst_data = []
			print res[0]
			# num += 1
			# print num
			if res[0] == 1:
				cv2.rectangle(img_color, (i, j), (i + width_std, j + height_std), (255, 0, 0), 3)
				num_hit += 1
			
			box = img[j:j + height_std2, i:i + width_std2]
			box_scale = cv2.resize(box, size_scale)
			hog = Hog_descriptor(box_scale, cell_size=8, bin_size=8)
			vector, image = hog.extract()
			tst_data.append(vector)
			res = CLASSFIER.predict(tst_data)
			tst_data = []
			print res[0]
			num += 1
			print num
			if res[0] == 1:
				cv2.rectangle(img_color, (i, j), (i + width_std, j + height_std), (255, 0, 0), 3)
				num_hit += 1

# hit = detecting(img)

endtime = datetime.datetime.now()
print 'time:', (endtime - starttime).seconds
print 'num hit:', num_hit

image_cv = Image.fromarray(cv2.cvtColor(img_color, cv2.COLOR_BGR2RGB))
image_cv.show()
print 'ok'