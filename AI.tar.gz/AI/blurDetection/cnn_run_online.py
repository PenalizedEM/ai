#!/usr/bin/python
#coding:utf-8

from __future__ import division
from keras.models import Sequential
import os, os.path
import cv2
import numpy as np
from PIL import Image, ImageFile, ImageDraw, ImageFont, ImageFilter
import scipy
import cv2
import MySQLdb
import sys
from keras.models import load_model
import time
ImageFile.LOAD_TRUNCATED_IMAGES = True

# path_pre = 'data/videopic/python_blur/'
filepath_model = "/data/videopic/python_blur/MotionBlur-detection-by-using-CNN-master/tangdouData/tangdoublur1122.h5"
# testblur_directory = 'MotionBlur-detection-by-using-CNN-master/data/s_cnn/test/0/blur/'
# testnoblur_directory = 'MotionBlur-detection-by-using-CNN-master/data/s_cnn/test/0/no_blur/'

files_path = '/data/videopic/2017'

filepath_model2 = '/Users/lilin/workspace_python/MotionBlur-detection-by-using-CNN-master/tangdouData/tangdoublur1122.h5'

MODEL_CNN = load_model(filepath_model)
pixel_block = 30


def mean_stddev(arr):
	im_array = np.array(arr)
	cvuint8 = cv2.convertScaleAbs(im_array)
	mean, stddev = cv2.meanStdDev(cvuint8)
	mean_val = mean[0][0]
	stddev_val = stddev[0][0]
	return mean_val, stddev_val

def cnnRun(files_path, scale):
	# blur = np.array([10])
	img_list = []
	total_box = 0
	sharpe_box = 0
	black_box = 0
	white_box = 0
	try:
		# im = Image.open(files_path).convert('F')
		input_img = cv2.imread(files_path)
	except IOError:
		print 'Error:没有找到文件或读取文件失败:', files_path
		# blur.append([[10]])
		return [], 11111, 0, 11111, white_box
	else:
		filesize = os.path.getsize(files_path)/1024
		if filesize > 1:
			sp = input_img.shape
			height = sp[0]
			width = sp[1]
			
			if scale != 1:
				h_box = int(height * 1)
				w_box = int(width * scale)
				h_start = 0 # int(height - h_box)
				w_start = int((width - w_box)*0.5)
				input_img_box = input_img[h_start:h_start+h_box, w_start:w_start+w_box]
				input_img = input_img_box
				height = h_box
				width = w_box
				# pil_img = Image.fromarray(input_img_box)
				# pil_img.show()
				
			for i in range(1, width-pixel_block-1, pixel_block):
				for j in range(1, height-pixel_block-1, pixel_block):
					total_box += 1
					box = input_img[j:j + pixel_block, i:i + pixel_block]
					# box_white = box
					box_gray = cv2.cvtColor(box, cv2.COLOR_BGR2GRAY)
					im_array = np.array(box_gray)
					cvuint8 = cv2.convertScaleAbs(im_array)
					# 均值和标准差
					mean, stddev = cv2.meanStdDev(cvuint8)
					mean_val = mean[0][0]
					stddev_val = stddev[0][0]

					if stddev_val > 8.9:
						# box = np.swapaxes(box, 0, 2)
						# img_list.append(box)
						sharpe_box += 1
					if mean_val < 60:
						black_box += 1
						
					
					box = np.swapaxes(box, 0, 2)
					img_list.append(box)
					
					box_b = cv2.split(box)[0]
					box_g = cv2.split(box)[1]
					box_r = cv2.split(box)[2]
					b_mean, b_stddev = mean_stddev(box_b)
					g_mean, g_stddev = mean_stddev(box_g)
					r_mean, r_stddev = mean_stddev(box_r)
					min_mean = g_mean if b_mean > g_mean else b_mean
					min_mean = r_mean if min_mean > r_mean else min_mean
					max_stddev = g_stddev if b_stddev < g_stddev else b_stddev
					max_stddev = r_stddev if max_stddev < r_stddev else max_stddev
					if min_mean > 148 and max_stddev < 23:
						white_box += 1
			
			if len(img_list):
				box_data = np.array(img_list)
				box_data = box_data.astype('float32')
				box_data /= 255
				cl = MODEL_CNN.predict_classes(box_data)
				# blur.append(cl[0])
				return cl, total_box, sharpe_box, black_box, white_box
			else:
				return [], total_box, sharpe_box, black_box, white_box
		else:
			print 'Error:没有找到文件或读取文件失败:', files_path
			# blur.append([[10]])
			return [], 11111, 0, 11111, white_box
	

# test model
# imgfilepath = '/Users/lilin/workspace_python/MotionBlur-detection-by-using-CNN-master/1500654710190.jpg'
# blur, total_box = cnnRun(imgfilepath, 1)
# length = len(blur)
# rate_box = length / total_box
# if rate_box < 0.1:
# 	# blur
# 	res = 1
# else:
# 	blur_list = blur.tolist()
# 	num_blur = blur_list.count(1)
# 	rate_blur = num_blur / length
#
# 	if rate_blur > 0.65:
# 		# blur
# 		res = 1
# 	elif rate_blur > 0.5:
# 		blur = cnnRun(imgfilepath, 0.5)
# 		blur_list = blur.tolist()
# 		length = len(blur)
# 		num_blur = blur_list.count(1)
# 		rate_blur = num_blur / length
# 		if rate_blur > 0.66:
# 			# blur
# 			res = 1



# blur = cnnRun('/Users/lilin/workspace_python/MotionBlur-detection-by-using-CNN-master/1500653437741.jpg')
# blur_list = blur.tolist()

# ft = open("result_blur_diff_0929_0.txt", 'wb')

db_conn = MySQLdb.connect(host='10.10.243.51',user='root',passwd='tangdouapp#123',db='2016hd',port=3306)
cursor = db_conn.cursor()


t_now = time.localtime()
t_tm_year = t_now.tm_year
t_tm_mon = t_now.tm_mon
t_tm_mday = t_now.tm_mday
t_tm_hour = t_now.tm_hour
t_tm_min = t_now.tm_min
t_tm_sec = t_now.tm_sec
t_tm_wday = t_now.tm_wday
t_tm_yday = t_now.tm_yday
t_tm_isdst = t_now.tm_isdst
t_ = (t_tm_year, t_tm_mon, t_tm_mday, t_tm_hour - 1, t_tm_min, t_tm_sec, t_tm_wday, t_tm_yday, t_tm_isdst)
before_time = time.strftime('%Y-%m-%d %H:%M:%S', t_)


sql = "select vid from data_pic_testing where checktime=0 and addtime>'%s'" % before_time
# sql = "select vid from data_pic_testing where sys_status=0"
# sql = "select vid from data_pic_testing where checktime=0 and addtime>'2017-11-1'" #
# sql = "select vid from data_pic_testing where status=1 and check_status=1" #blur

cursor.execute(sql)
ars = cursor.fetchall()
# num_blur_total = len(ars)
# print '模糊图片总数:', num_blur_total
# num_detection_blur = 0
print '查询到:', len(ars)
# time.sleep(10)
num_det = 0
num_det_sleep = 0
for rs in ars:
	# non blur
	res = 0
	flag_blur = 0
	cmd = 'find ' + files_path + ' -name ' + str(rs[0]) + '.jpg'
	url = os.popen(cmd).read()
	url2 = url.strip()
	if url2 != '':
		blur, total_box, sharpe_box, black_box, num_white = cnnRun(url2, 1)
		length = len(blur)
		if length == 0:
			continue
		blur_list = blur.tolist()
		num_blur = blur_list.count(1)
		rate_blur = num_blur / length
		rate_sharpe = sharpe_box / total_box
		rate_black = black_box / total_box
		rate_white = num_white / total_box
		if rate_blur > 0.93:
			# blur
			res = 1
			flag_blur = 1
		if rate_white > 0.7 and flag_blur == 0:
			# no blur
			res = 0
			flag_blur = 1
		if rate_sharpe < 0.1 or rate_black > 0.74:
			# blur
			res = 1
		elif flag_blur == 0:
			# blur_list = blur.tolist()
			# num_blur = blur_list.count(1)
			# rate_blur = num_blur/length
			# if rate_blur > 0.93:
				# blur
				# res = 1
				# flag_blur = 1
			if rate_blur > 0.86 and rate_white < 0.47 and flag_blur == 0:
				# blur
				res = 1
				flag_blur = 1
			if rate_blur > 0.82 and rate_white < 0.45 and flag_blur == 0:
				# blur
				res = 1
				flag_blur = 1
			if rate_blur > 0.75 and rate_white < 0.4 and flag_blur == 0:
				# blur
				res = 1
				flag_blur = 1
			if rate_blur > 0.5 and rate_white < 0.4 and flag_blur == 0:
				blur, total_box_nouse, sharpe_box_nouse, black_bo_nouse, num_white = cnnRun(url2, 0.5)
				blur_list = blur.tolist()
				length = len(blur)
				num_blur = blur_list.count(1)
				rate_blur = num_blur / length
				if rate_blur > 0.69:
					# blur
					res = 1
					# num_detection_blur += 1
				else:
					# non blur
					res = 0
			# else:
				# non blur
				# res = 0
		
		now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
		sql_temp = "update data_pic_testing set sys_status='%s',checktime='%s' where vid='%s'" % (res, now_time, rs[0])
		# print sql_temp, num_det
		cursor.execute(sql_temp)
		db_conn.commit()
	
		num_det += 1
		num_det_sleep += 1
		
	else:
		print 'Not find url of vid!'
	if num_det_sleep == 10000:
		print "已处理图片数量为:", num_det
		# ft.close
		# db_conn.close()
		# sys.exit(0)
		num_det_sleep = 0
		time.sleep(60)

db_conn.close()
print "执行完毕!总共处理的图片数量为:", num_det
sys.exit(0)
