#!/usr/bin/python
#coding:utf-8


from keras.models import Sequential
from keras.layers import Dense, Flatten, Dropout
from keras.layers.convolutional import Conv2D, MaxPooling2D
from keras.utils.np_utils import to_categorical
import numpy as np
import os, os.path
import cv2
from keras.optimizers import RMSprop, SGD,Adam
from keras.utils import np_utils
from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split
import random


# -----------------------------------------
class MyAlexnet():
	## alexnet结构
	def __init__(self):
		self.model = self.alexnet()
		sgd = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
		self.model.compile(loss='categorical_crossentropy', optimizer='sgd', metrics=["accuracy"])
		print(self.model.summary())
	
	def alexnet(self):
		model = Sequential()
		model.add(Conv2D(96, (11, 11), strides=(4, 4), input_shape=(227, 227, 3), padding='valid', activation='relu',
		                 kernel_initializer='uniform'))
		model.add(MaxPooling2D(pool_size=(3, 3), strides=(2, 2)))
		model.add(Conv2D(256, (5, 5), strides=(1, 1), padding='same', activation='relu', kernel_initializer='uniform'))
		model.add(MaxPooling2D(pool_size=(3, 3), strides=(2, 2)))
		model.add(Conv2D(384, (3, 3), strides=(1, 1), padding='same', activation='relu', kernel_initializer='uniform'))
		model.add(Conv2D(384, (3, 3), strides=(1, 1), padding='same', activation='relu', kernel_initializer='uniform'))
		model.add(Conv2D(256, (3, 3), strides=(1, 1), padding='same', activation='relu', kernel_initializer='uniform'))
		model.add(MaxPooling2D(pool_size=(3, 3), strides=(2, 2)))
		model.add(Flatten())
		model.add(Dense(4096, activation='relu', name="Dense_1"))
		model.add(Dropout(0.5))
		model.add(Dense(4096, activation='relu', name="Dense_2"))
		model.add(Dropout(0.5))
		model.add(Dense(32, activation='relu', name="Dense_3"))
		model.add(Dense(2, activation='softmax'))
		return model


def get_url_data(dir_neg, dir_pos):
	# 负样本
	img_data_list_neg = []
	img_list = os.listdir(dir_neg)
	for img in img_list:
		if '.jpg' in img:
			img_data_list_neg.append(dir_neg + img)
	len_neg = len(img_data_list_neg)
	labels_neg = np.ones((len_neg,), dtype='int64')
	
	# 正样本
	img_data_list_pos = []
	img_list = os.listdir(dir_pos)
	img_list = os.listdir(dir_pos)
	for img in img_list:
		if '.jpg' in img:
			img_data_list_pos.append(dir_pos + img)
	len_pos = len(img_data_list_pos)
	labels_pos = np.ones((len_pos,), dtype='int64')
	labels_pos[:] = 0
	
	data = np.concatenate((img_data_list_neg, img_data_list_pos), axis=0)
	labels = np.concatenate((labels_neg, labels_pos), axis=0)
	num_classes = 2
	Y = np_utils.to_categorical(labels, num_classes)
	
	# Shuffle the dataset
	x, y = shuffle(data, Y, random_state=2)
	# Split the dataset
	X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=2)
	
	return X_train, X_test, y_train, y_test


def load_image_data(img_url):
	input_img = cv2.imread(img_url)
	slide_step = 60
	train_img_size = 227
	null_img_size = 10
	size_wh = input_img.shape
	size_h = size_wh[0]
	size_w = size_wh[1]
	img_data_list = []
	for i in range(null_img_size, size_w - train_img_size, slide_step):
		for j in range(null_img_size, size_h - train_img_size, slide_step):
			if (i + train_img_size < size_w and j + train_img_size < size_h):
				input_img_crop = input_img[j:j + train_img_size, i:i + train_img_size]
				img_data_list.append(input_img_crop)
	img_data = np.array(img_data_list)
	img_data = img_data.astype('float32')
	img_data /= 255
	
	return img_data


def load_image_data_frame(frames):
	#return [load_image_data(x) for x in frames]frames
	return load_image_data(frames)


def frame_generator(batch_size, train_test,
					X_train, X_test, y_train, y_test):
	if train_test == 'train':
		data = X_train
		label = y_train
	else:
		data = X_test
		label = y_test
	
	while 1:
		X, y = [], []
		for _ in range(batch_size):
			sequence = None
			sample = random.choice(data)
			sequence = load_image_data_frame(sample)
			
			index = data.tolist().index(sample)
			sample_label = label[index]
			num_of_samples = sequence.shape[0]
			num_classes = 2 
			labels_extend = np.ones((num_of_samples,num_classes), dtype='int64')
			labels_extend[:] = sample_label
			
			X.extend(sequence.tolist())
			y.extend(labels_extend.tolist())
			X_len = len(X)
			num_pop = 0
			if X_len > batch_size:
				num_pop = X_len - batch_size
				for _num_pop in range(num_pop):
					X.pop()
					y.pop()
				break
		yield np.array(X), np.array(y)


def train(model_save_path, train_dir_neg, train_dir_pos):
	my_alexnet = MyAlexnet()
	## 训练
	epochs = 100
	learning_rate = 0.01
	decay = learning_rate / epochs
	adam = Adam(lr=learning_rate)
	#sgd = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
	#model.compile(loss='categorical_crossentropy', optimizer='sgd',metrics=["accuracy"])
	#model.summary()
	my_alexnet.model.get_config()
	my_alexnet.model.layers[0].get_config()
	my_alexnet.model.layers[0].input_shape
	my_alexnet.model.layers[0].output_shape
	my_alexnet.model.layers[0].get_weights()
	np.shape(my_alexnet.model.layers[0].get_weights()[0])
	my_alexnet.model.layers[0].trainable
	# Use standard fit.
	#hist = model.fit(X_train, y_train, batch_size=128, nb_epoch=epochs, verbose=1, validation_data=(X_test, y_test))
	
	# Use fit generator.
	batch_size = 100
	X_train, X_test, y_train, y_test = get_url_data(dir_neg=train_dir_neg, dir_pos=train_dir_pos)
	generator = frame_generator(batch_size=batch_size, train_test='train',
								X_train=X_train, X_test=X_test, y_train=y_train, y_test=y_test)
	#g1 = generator.next()
	#g2 = generator.next()
	
	val_generator = frame_generator(batch_size=batch_size, train_test='test',
									X_train=X_train, X_test=X_test, y_train=y_train, y_test=y_test)
	steps_per_epoch = ((len(X_train.tolist())+len(X_test.tolist())) * 0.7) // batch_size
	
	if steps_per_epoch == 0:
		steps_per_epoch = 1
	my_alexnet.model.fit_generator(
		generator=generator,
		steps_per_epoch=steps_per_epoch,
		epochs=epochs,
		verbose=1,
		validation_data=val_generator,
		validation_steps=10
	)
	
	# 保存模型
	file = open(model_save_path, 'a')
	my_alexnet.model.save(model_save_path)
	file.close()
	
	
if __name__ == '__main__':
	## 读入训练数据
	root_path = "/Users/lilin/workspace_python/alexnet"
	train_dir_neg = root_path + "/alexnet_neg2/"
	train_dir_pos = root_path + "/alexnet_pos2/"
	
	model_save_path = root_path + "/" + "alexnet_attractive_20180413.h5"
	train(model_save_path=model_save_path,
	      train_dir_neg=train_dir_neg, train_dir_pos=train_dir_pos)
