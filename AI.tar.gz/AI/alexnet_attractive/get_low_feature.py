#!/usr/bin/python
#coding:utf-8


import cv2
import numpy as np
from skimage import feature as skft
from PIL import Image
from scipy.ndimage import filters


# image = cv2.imread("/Users/lilin/workspace_python/alexnet/1500657796308.jpg",cv2.IMREAD_COLOR)
#image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
#hist = cv2.calcHist([image], [0,1], None, [180,256], [0, 180, 0, 256])
#print 'end!'
#comp = cv2.compareHist(hist1, hist2, cv2.HISTCMP_BHATTACHARYYA)

def texture_feature(image):
	image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
	img_resize = cv2.resize(image, (512, 512), interpolation=cv2.INTER_AREA)
	img_data = np.zeros((9,171,171))
	index = 0
	data = np.zeros((513, 513))
	print img_resize.shape[0],img_resize.shape[1]
	data[0:img_resize.shape[0], 0:img_resize.shape[1]] = img_resize
	for row in np.arange(3):
		for col in np.arange(3):
			img_data[index,:,:] = data[171*row:171*(row+1), 171*col:171*(col+1)]
			index += 1
	
	radius = 1
	n_point = radius * 4
	hist = np.zeros((9,16))
	for i in np.arange(9):
		lbp = skft.local_binary_pattern(img_data[i], n_point, radius, 'default')
		max_bins = int(lbp.max()+1)
		hist, _ = np.histogram(lbp, normed=True, bins=max_bins, range=(0, max_bins))
	
	return hist


def corner_feature(image):
	#image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
	#image = np.float32(image)
	#corners = cv2.cornerHarris(image, 2, 3, 0.04)
	#corners = cv2.dilate(corners, None)
	#corners = cv2.goodFeaturesToTrack(image, 50, 0.01, 10)
	#corners = np.int0(corners)
	
	pimg = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2GRAY))
	I = np.array(pimg)
	m, n = I.shape
	Ix = np.zeros(I.shape)
	Iy = np.zeros(I.shape)
	filters.gaussian_filter(I, (3, 3), (0, 1), Ix)
	filters.gaussian_filter(I, (3, 3), (0, 1), Iy)
	Ixx = np.multiply(Ix, Ix)
	Iyy = np.multiply(Iy, Iy)
	Ixy = np.multiply(Ix, Iy)
	Wxx = filters.gaussian_filter(Ixx, 3)
	Wyy = filters.gaussian_filter(Iyy, 3)
	Wxy = filters.gaussian_filter(Ixy, 3)
	M = np.zeros([2, 2])
	R = np.zeros(I.shape)
	for i in range(m):
		for j in range(n):
			M[0, 0] = Wxx[i, j]
			M[1, 0] = Wxy[i, j]
			M[0, 1] = Wxy[i, j]
			M[1, 1] = Wyy[i, j]
			R[i, j] = -(np.linalg.det(M) - 0.06*(np.trace(M)**2))
	coord1 = []
	coord2 = []
	num = 0
	for i in range(m):
		for j in range(n):
			if R[i, j] > 5000:
				coord1.append(i)
				coord2.append(j)
				num += 1
				
	return num
	
	
def color_feature(image):
	b_hist = cv2.calcHist([image], [0], None, [32], [0.0, 255.0])
	g_hist = cv2.calcHist([image], [1], None, [32], [0.0, 255.0])
	r_hist = cv2.calcHist([image], [2], None, [32], [0.0, 255.0])
	
	return b_hist, g_hist, r_hist


if __name__ == '__main__':
	image = cv2.imread("/Users/lilin/workspace_python/alexnet/1500657796308.jpg", cv2.IMREAD_COLOR)
	texture = texture_feature(image)
	corner = corner_feature(image)
	b, g, r = color_feature(image)
	print 'end!'