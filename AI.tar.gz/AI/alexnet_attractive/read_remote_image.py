#!/usr/bin/python
#coding:utf-8


import MySQLdb
import cv2
import urllib
import numpy as np
import time


def url_to_image(url):
	resp = urllib.urlopen(url)
	image = np.asanyarray(bytearray(resp.read()), dtype='uint8')
	image = cv2.imdecode(image, cv2.IMREAD_COLOR)
	return image


# input_img = url_to_image('http://aimg.tangdou.com//public/video/1427445363.jpg')
# sp = input_img.shape
# height = sp[0]
# width = sp[1]

def connect_db():
	db_conn = MySQLdb.connect(host='10.10.120.205',user='root',passwd='tangdouapp#123',db='tangdouapp',port=3306)
	cursor = db_conn.cursor()
	sql='select vid, pic from video'
	cursor.execute(sql)
	ars = cursor.fetchall()
	
	return ars

if __name__ == '__main__':
	ars = connect_db()
	print '查询到:', len(ars)
	for rs in ars:
		print 'rs:', rs
		print 'rs[0]:', str(rs[0])
		print 'rs[1]:', str(rs[1])
		vid = str(rs[0])
		pic = str(rs[1])
		imgurl = "http://aimg.tangdou.com/" + pic
		# cv type image
		input_img = url_to_image(imgurl)
		sp = input_img.shape
		height = sp[0]
		width = sp[1]
		print 'height:', sp[0]
		print 'width:', sp[1]
		time.sleep(10)