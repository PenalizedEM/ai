#!/usr/bin/python
#coding:utf-8


import numpy as np
from keras.models import Sequential
from keras.layers.convolutional import Conv2D, MaxPooling2D
from keras.layers import Dense, Flatten, Dropout
from keras.models import Model, load_model
import cv2


filepath_model = '/Users/lilin/workspace_python/alexnet/alexnet_attractive_20180329_2.h5'
MODEL = load_model(filepath_model)


file_path = '/Users/lilin/workspace_python/alexnet/1500657796308.jpg'
input_img = cv2.imread(file_path)
sp = input_img.shape
height = sp[0]
width = sp[1]
img_data_list = []
for i in range(10, width - 227, 80):
	for j in range(10, height - 227, 80):
		if (i + 227 < width and j + 227 < height):
			input_img_crop = input_img[j:j + 227, i:i + 227]
			img_data_list.append(input_img_crop)
if len(img_data_list):
	box_data = np.array(img_data_list)
	box_data = box_data.astype('float32')
	box_data /= 255
	cl = MODEL.predict_classes(box_data)
print 'cl:', cl
length = len(cl)
if length == 0:
	print '0'
else:
	cl_list = cl.tolist()
	num = cl_list.count(1)
	rate = num / float(length)
if rate > 0.5:
	# 没有吸引力
	res = 1
else:
	# 有吸引力
	res = 0
	


input_img_crop = input_img[20:height-40, 20:width-40]
input_img_crop_resize = cv2.resize(input_img_crop, (227, 227), interpolation=cv2.INTER_AREA)
img_data_list_resize = []
img_data_list_resize.append(input_img_crop_resize)
box_data_resize = np.array(img_data_list_resize)
box_data_resize = box_data_resize.astype('float32')
box_data_resize /= 255
dense3_layer_model = Model(inputs=MODEL.input, outputs=MODEL.get_layer('Dense_3').output)
dense3_output = dense3_layer_model.predict(box_data_resize)
print dense3_output.shape
print dense3_output[0]
print 'end!'